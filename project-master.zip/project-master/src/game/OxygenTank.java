package game;

import edu.monash.fit2099.engine.Item;

/**
 * Class defining Oxygen tank
 *
 */
public class OxygenTank extends Item {
	// private int oxygenPoints = 10;
	private static int totalOxygenPoints;
	private static boolean hasInstance = false;

	/**
	 * Constructor
	 * 
	 * @param points oxygen points
	 */
	public OxygenTank(int points) {
		super("OxygenTank", 'T');
		// TODO Auto-generated constructor stub

		if (hasInstance == false) {
			totalOxygenPoints = points;
		} else {
			totalOxygenPoints += points;
		}
		hasInstance = true;
	}

	/**
	 * method to get total oxygen points
	 * 
	 * @return total oxygen points
	 */
	public int getOxygenPoints() {
		return totalOxygenPoints;
	}

	/**
	 * method to add oxygen points
	 * 
	 * @param number oxygen points
	 */
	public void addOxygenPoints(int number) {
		totalOxygenPoints += number;
	}

	/**
	 * method to subtract oxygen points
	 * 
	 * @param number oxygen points
	 */
	public void reduceOxygenPoints(int number) {
		totalOxygenPoints -= number;
	}

}
