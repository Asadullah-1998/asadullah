package game;
import edu.monash.fit2099.engine.*;
/**
 * Class representing Key
 *
 */
public class Key extends Item {

	/**Constructor.
	 * @param k name of the key
	 * @param c	character to represent key on the map
	 */
	public Key(String k, char c) {
		// TODO Auto-generated constructor stub
		super(k,c);
		this.addSkill(Keyskill.OPENDOOR);
		canBePicked();

	}
	
	
	
	public void canBePicked() {
		this.getAllowableActions().clear();
		
		this.getAllowableActions().add(new DropItemAction(this));
	}
	
	public void addSkill(Keyskill skill) {
		skills.addSkill(skill);
	}

}
