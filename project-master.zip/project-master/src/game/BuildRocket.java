package game;
import edu.monash.fit2099.engine.*;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Class that build the rocket.
 */
public class BuildRocket extends Action{
    private String buildQuery = "Do you want to build the rocket now?\ny: Yes\nn: No";
    private Display display;

    private String engineName;
    private String bodyName;
    private boolean canMake;
    private Location location;

    private GameMap goToMap;
    private Location goToLocation;

    /**
     * Constructor.
     * @param canMake1 a boolean
     * @param location1 location of the rocket pad
     */

    public BuildRocket(boolean canMake1, Location location1, Location goToLocation1){
        super();
        display = new Display();

        bodyName = "RocketBody";
        engineName = "RocketEngine";
        canMake = canMake1;

        location = location1;
        //goToMap = goToMap1;
        goToLocation = goToLocation1;

    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#execute(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.GameMap)
     * If the player fulfills the requirements to build a rocket, a new rocket is built.
     * Otherwise, it'll informed player it doesn't have the required components.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (canMake) {
            buildTheRocket(actor,map);
        } else{
            display.println("You do not have the required components");
        }

        return menuDescription(actor);
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#menuDescription(edu.monash.fit2099.engine.Actor)
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " Interact with the pad";
    }

    @Override
    public String hotKey() {
        return "";
    }


    /**
     * Detects if user inputs y, then a new rocket is built.
     * @param actor player that the user control
     * @param map	map of the game
     */
    public void buildTheRocket(Actor actor, GameMap map){
        display.println(buildQuery);
        char s = display.readChar();

        if (s == 'y'){
            buildTheRocket2(actor, map);
        }
    }

    /**
     * Checks if the player have rocket engine and rocket body.
     * If so, removes it from player and adds a rocket to the player current location.
     * @param actor player that user control
     * @param map map of the game
     */
    public void buildTheRocket2(Actor actor, GameMap map){
        List<Item> items1 = actor.getInventory();
        for (int i = 0; i < items1.size(); i++){
            if (items1.get(i).toString().equals(bodyName)){
                actor.removeItemFromInventory(items1.get(i));
            }
            if (items1.get(i).toString().equals(engineName)){
                actor.removeItemFromInventory(items1.get(i));
            }
        }

        Rocket rocket = new Rocket (new Location(goToLocation.map(),goToLocation.x(),goToLocation.y()),goToLocation.map(),actor,"to Moon");
        location.setGround(new Floor());
        location.setGround(rocket);
    }
}
