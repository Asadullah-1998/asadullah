package game;
import edu.monash.fit2099.engine.*;


/**
 * Class for player to talk to certain characters
 *
 */
public class Talk extends Action {

    private Actor subject;
    private String dialogue;
    private Display display;
    private Actor thisActor;


    /**
     * Constructor.
     * @param subject1
     * @param thisActor1
     * @param dialogue1
     */
    public Talk(Actor subject1, Actor thisActor1, String dialogue1){
        this.subject = subject1;
        this.dialogue = dialogue1;
        display = new Display();
        this.thisActor = thisActor1;


    }



    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#execute(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.GameMap)
     */
    public String execute(Actor actor, GameMap map) {
        display.println(dialogue);
        return menuDescription(actor);
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#menuDescription(edu.monash.fit2099.engine.Actor)
     */
    public String menuDescription(Actor actor) {
        return actor + " Talk to "+this.thisActor;
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#hotKey()
     */
    public String hotKey() {
        return "";
    }


}
