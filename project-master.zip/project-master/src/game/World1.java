package game;
import edu.monash.fit2099.engine.*;

import java.util.List;


/**
 * Class to affect game over when yugo maxx dead body is brought back to earth
 */
public class World1 extends World {
    private GameMap mapToQuit;

    /**
     * Constructor.
     * @param display
     */
    public World1(Display display){
        super(display);

    }

    /**
     * getters
     * @param map1 map to quit
     */
    public void setMapToQuit(GameMap map1){
        mapToQuit = map1;
    }


    public List<Actor> getActorLocations(){
        return null;
    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.World#run()
     */
    @Override
    public void run() {
        if(player == null)
            throw new IllegalStateException();

        while (stillRunning() && !(isYugoInMap(actorLocations.locationOf(player).map()))) {
            GameMap playersMap = actorLocations.locationOf(player).map();
            playersMap.draw(display);
            for (Actor actor : actorLocations) {
                if (stillRunning() && !(isYugoInMap(actorLocations.locationOf(player).map()))) {
                    playersMap = actorLocations.locationOf(player).map();
                    if (actorLocations.locationOf(actor).map().equals(playersMap)) {
                        processActorTurn(actor);
                    }
                }
            }
        }
        display.println(endGameMessage());
    }


    public boolean isYugoInMap(GameMap map1){
        if (map1 == mapToQuit) {
            for (Item items : actorLocations.locationOf(player).getItems()) {
                if (items.toString().equals("Sleeping Yugo Maxx")) {
                    return true;
                }
            }
        }


        return false;
    }

    /*@Override
    public void addMap(GameMap map) {
        map.
    }*/
}
