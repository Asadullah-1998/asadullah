package game;

import edu.monash.fit2099.engine.*;


/**
 * Class for enemies to have a following behavior.
 *
 */
public class FollowBehaviour implements ActionFactory {

	private Actor target;

	/**
	 * Construcotr.
	 * @param subject
	 */
	public FollowBehaviour(Actor subject) {
		this.target = subject;
	}

	/* (non-Javadoc)
	 * @see game.ActionFactory#getAction(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.GameMap)
	 */
	@Override
	public Action getAction(Actor actor, GameMap map) {
		Location here = map.locationOf(actor);
		Location there = map.locationOf(target);

		int currentDistance = distance(here, there);
		for (Exit exit : here.getExits()) {
			Location destination = exit.getDestination();
			if (destination.canActorEnter(actor)) {
				int newDistance = distance(destination, there);
				if (newDistance < currentDistance) {
					return new MoveActorAction(destination, exit.getName());
				}
			}
		}
		return null;
	}

	// Manhattan distance.
	private int distance(Location a, Location b) {
		return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
	}
}