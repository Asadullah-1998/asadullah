package game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import edu.monash.fit2099.engine.*;
/**
 * A class representing Goons.
 *
 */
public class Goons extends Actor {
    private Random rand = new Random();
    private Actor player;
    public List<ActionFactory> actionFactories = new ArrayList<ActionFactory>();

    // Goons have 50 hitpoints and are always represented with a y
    /**Constructor.
     * @param name name to call Goons
     * @param player player that the user control
     */
    // Goons have 50 hitpoints and are always represented with a y
    public Goons(String name, Actor player1) {
        super(name, 'G', 5, 50);
        addBehaviour(new Insult(player1));
        addBehaviour(new FollowBehaviour(player1));
        player = player1;

    }

    /**
     * method to add action to action factories
     * @param behaviour
     */
    private void addBehaviour(ActionFactory behaviour) {
        actionFactories.add(behaviour);
    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Actor#getIntrinsicWeapon()
     */
    protected IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(10, "punches");
    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Actor#playTurn(edu.monash.fit2099.engine.Actions, edu.monash.fit2099.engine.GameMap, edu.monash.fit2099.engine.Display)
     *
     */
    @Override
    public Action playTurn(Actions actions, GameMap map, Display display) {
        for (ActionFactory factory : actionFactories) {
            Action action = factory.getAction(this, map);
            if (action != null) {
                return action;
            }
        }
        Actions newActions = new Actions();

        newActions.add(new SkipTurnAction());


        for (Action action1: actions){
            if (action1 instanceof MoveActorAction || action1 instanceof AttackAction){
                newActions.add(action1);
            }
        }
        return super.playTurn(newActions,map,display);
    }


}
