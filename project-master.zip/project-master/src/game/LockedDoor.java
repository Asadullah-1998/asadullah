package game;

import java.util.List;

import edu.monash.fit2099.engine.Actions;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Location;


public class LockedDoor extends Ground {

	public LockedDoor() {
		super('+');
	}
	
	@Override
	public boolean canActorEnter(Actor actor) {
		if (actor.hasSkill(Keyskill.OPENDOOR)){
			return true ;
		}
		else{
			return false;
		}
	}
	
	
	@Override
	public boolean blocksThrownObjects() {
		return true;
	}
	

}
