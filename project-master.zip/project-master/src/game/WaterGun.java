package game;
import edu.monash.fit2099.engine.*;



/**
 * Class about water gun
 *
 */
public class WaterGun extends Item {

    private boolean isFull;

    public WaterGun(){
        super("Water Gun",'w');
        isFull = false;
    }

    public boolean getFull(){
        return isFull;
    }

    public void setFull(boolean value){
        isFull = value;
    }



}
