package game;

import edu.monash.fit2099.engine.*;


/**
 * Class that allows player to draw water when using water gun.
 *
 */
public class DrawWaterAction extends Action {


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#execute(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.GameMap)
     */
    @Override
    public String execute(Actor actor, GameMap map) {

        for (Item item:actor.getInventory()){
            if (item.toString().equals("Water Gun")){
                if (((WaterGun) item).getFull() == false) {
                    ((WaterGun) item).setFull(true);
                    return menuDescription(actor);
                } else{
                    return "Cannot draw anymore water. The gun is full";
                }
            }
        }


        return "cannot draw water because no gun";
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#menuDescription(edu.monash.fit2099.engine.Actor)
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor+" draws water from the pool";
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#hotKey()
     */
    @Override
    public String hotKey() {
        return "";
    }
}
