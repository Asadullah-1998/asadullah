package game;

import edu.monash.fit2099.engine.*;
/**
 *
 * A class representing Dr.Maybe
 *
 */
public class DrMaybe extends Actor {
    private Actor player;
    private Item rocketEngine;

    /**
     * Constructor.
     * @param player1 name to call Dr.Maybe
     *
     */

    /**
     * Constructor
     * @param player1 player that user controls 
     */
    public DrMaybe(Actor player1){
        super("Dr. Maybe", 'D', 5, 25);
        this.rocketEngine = new  Item("RocketEngine",'e');

        addRocketEngine();
        this.player = player1;

    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Actor#playTurn(edu.monash.fit2099.engine.Actions, edu.monash.fit2099.engine.GameMap, edu.monash.fit2099.engine.Display)
     * Makes Dr.Maybe to only skip turn or attack player.
     */
    @Override
    public Action playTurn(Actions actions, GameMap map, Display display) {


        Actions newActions = new Actions();
        newActions.add(new SkipTurnAction());


        for (Action action1:actions){
            if (action1 instanceof AttackAction){
                newActions.add(action1);
            }
        }


        return super.playTurn(newActions,map,display);


    }

    /**
     * Adds Rocket Engine that can be dropped to Dr.Maybe
     */
    public void addRocketEngine(){

        this.rocketEngine.getAllowableActions().clear();
        this.rocketEngine.getAllowableActions().add(new DropItemAction(this.rocketEngine));
        addItemToInventory(this.rocketEngine);

    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Actor#getIntrinsicWeapon()
     * Dr.Maybe punches player for 3 damage.
     */
    @Override
    protected IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(3,"Punches");
    }


}
