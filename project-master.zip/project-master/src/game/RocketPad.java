package game;
import edu.monash.fit2099.engine.*;

/**
 * Class representing RocketPad
 * hasBody boolean that checks for rocket body
 * hasEngine boolean that checks for rocket engine
 * engineName is referring to rocket engine
 * bodyname is referring to rocket body.
 */
public class RocketPad extends Ground {

    private boolean hasBody;
    private boolean hasEngine;
    private String engineName;
    private String bodyName;

    private Player1 player;

    private Location goToLocation;


    /**
     * Constructor.
     * @param player1
     * @param goToLocation1
     */
    public RocketPad(Player1 player1, Location goToLocation1){

        super('R');
        bodyName = "RocketBody";
        engineName = "RocketEngine";
        player = player1;
        goToLocation = goToLocation1;

    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Ground#allowableActions(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.Location, java.lang.String)
     */
    @Override
    public Actions allowableActions(Actor actor, Location location, String direction) {

        if (actor.equals(player)){
            for (Item item1:actor.getInventory()) {
                if (item1.toString().equals(bodyName)){
                    hasBody = true;
                }
                if (item1.toString().equals(engineName)){
                    hasEngine = true;
                }
            }
        }

        if (hasBody && hasEngine){
            return new Actions(new BuildRocket(true,location,goToLocation));
        }
        else {
            return new Actions(new BuildRocket(false,location,goToLocation));
        }

    }

    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
    }
}
