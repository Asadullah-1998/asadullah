package game;

import java.util.Random;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.Range;

/**
 * Class defining Ninja Attack action
 *
 */
public class NinjaAttack extends Action implements ActionFactory {

	private Player1 subject;
	private Ninja ninja;
	private Random rand = new Random();

	private static int stunTurn = 2;

	/**
	 * Constructor.
	 * 
	 * @param actor   ninja
	 * @param subject player
	 */
	public NinjaAttack(Ninja actor, Player1 subject) {
		this.ninja = actor;
		this.subject = subject;
	}

//	@Override
//	public String execute(Actor actor, GameMap map) {
//		return actor + " throws a bag of stun powder at " + subject + "." + System.lineSeparator()
//				+ "This has a 50% chance of getting hit.";
//	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * edu.monash.fit2099.engine.Action#execute(edu.monash.fit2099.engine.Actor,
	 * edu.monash.fit2099.engine.GameMap)
	 */
	@Override
	public String execute(Actor actor, GameMap map) {
		if (rand.nextDouble() <= 0.50 && subject.getStunned() == false) {
			System.out.println("stunned");
			// if (subject instanceof Player1 && ((Player1) subject).getStunned() == false)
			// {
			if (subject.getStunned() == false) {
				subject.setStunned(true);
				ninja.moveActorToPosition(actor, subject, map);
			}
			return menuDescription(ninja);
		} else {
			return subject + " dodges stun powder thrown by " + actor;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see game.ActionFactory#getAction(edu.monash.fit2099.engine.Actor,
	 * edu.monash.fit2099.engine.GameMap)
	 */
	@Override
	public Action getAction(Actor actor, GameMap map) {
		Location here = map.locationOf(ninja);
		Location there = map.locationOf(subject);

		Range xs, ys;
		if (here.x() == there.x() || here.y() == there.y()) {
			xs = new Range(Math.min(here.x(), there.x()), Math.abs(here.x() - there.x()) + 1);
			ys = new Range(Math.min(here.y(), there.y()), Math.abs(here.y() - there.y()) + 1);

			if (Math.abs(here.x() - there.x()) > 5 || Math.abs(here.y() - there.y()) > 5) {
				return null;
			}

			for (int x : xs) {
				for (int y : ys) {
					if (map.at(x, y).getGround().blocksThrownObjects())
						return null;
				}
			}
			return this;
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * edu.monash.fit2099.engine.Action#menuDescription(edu.monash.fit2099.engine.
	 * Actor)
	 */
	@Override
	public String menuDescription(Actor actor) {
		return actor + " stuns " + subject;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.monash.fit2099.engine.Action#hotKey()
	 */
	@Override
	public String hotKey() {
		return "";
	}

	/**
	 * method to move ninja one unit away from player
	 * 
	 * @param actor   ninja
	 * @param subject player
	 * @param map     map that the ninja and player are currently in
	 */
	public void moveActorToPosition(Actor actor, Actor subject, GameMap map) {
		Location here = map.locationOf(actor);
		Location there = map.locationOf(subject);
		Location positionToMove = new Location(map, here.x(), here.y());

		if (here.x() == there.x()) {
			if (here.x() - there.x() < 0) {
				positionToMove = new Location(map, here.x() + 1, here.y());
			} else {
				positionToMove = new Location(map, here.x() - 1, here.y());
			}
		}

		if (here.y() == there.y()) {
			if (here.y() - there.y() < 0) {
				positionToMove = new Location(map, here.x(), here.y() + 1);
			} else {
				positionToMove = new Location(map, here.x(), here.y() - 1);
			}
		}

		// if (positionToMove.getDisplayChar() == '.'){
		if (positionToMove.canActorEnter(actor)) {
			map.moveActor(actor, positionToMove);
			// }
		}
	}
}
