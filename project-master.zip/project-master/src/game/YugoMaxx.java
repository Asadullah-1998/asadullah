package game;
import edu.monash.fit2099.engine.*;


/**
 * Class defining YugoMaxx
 *
 */
public class YugoMaxx extends Actor {

    /**
     * Constructor
     */
    public YugoMaxx(){
        super("Yugo Maxx",'Y',5,5);
        addSkill(Keyskill.EXOSKELETON);
    }





    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Actor#getIntrinsicWeapon()
     */
    protected IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(10, "punches");
    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Actor#getAllowableActions(edu.monash.fit2099.engine.Actor, java.lang.String, edu.monash.fit2099.engine.GameMap)
     */
    @Override
    public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {

        if (hasSkill(Keyskill.EXOSKELETON)){
            return new Actions(new WaterGunAttack(this));
        }

        return super.getAllowableActions(otherActor, direction, map);
    }
}
