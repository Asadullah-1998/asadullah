package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actions;
import edu.monash.fit2099.engine.DropItemAction;
import edu.monash.fit2099.engine.Item;

/**
 * Class defining spacesuit item
 *
 */
public class Spacesuit extends Item {

	/**
	 * Constructor
	 */
	public Spacesuit() {
		super("Spacesuit", 's');
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.monash.fit2099.engine.Item#getAllowableActions()
	 */
	@Override
	public Actions getAllowableActions() {
		for (Action action1 : super.getAllowableActions()) {
			if (action1 instanceof DropItemAction) {
				return new Actions();
			}
		}
		return super.getAllowableActions();
	}
}
