package game;
import edu.monash.fit2099.engine.*;


/**
 * Class representing GivePlans
 *
 */
public class GivePlans extends Action {
    private Actor thisActor;
    private Item itemToGive;
    private Player1 player;

    /**
     * Constructor.
     * @param thisActor1 refers to Q
     * @param itemToGive1 rocket plans
     */

    public GivePlans(Actor thisActor1, Item itemToGive1, Player1 player1){
        thisActor = thisActor1;
        itemToGive = itemToGive1;
        player = player1;
    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#execute(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.GameMap)
     * player remove rocket plans from inventory and adds rocket body to it.
     */
    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#execute(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.GameMap)
     */
    @Override
    public String execute(Actor actor, GameMap map) {

        player.removeItemFromInventory(itemToGive);

        player.giveItem(new Item("RocketBody",'r'));
        return menuDescription(actor);
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#menuDescription(edu.monash.fit2099.engine.Actor)
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor+" gives plans to "+thisActor;
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#hotKey()
     */
    @Override
    public String hotKey() {
        return "";
    }
}
