package game;

import java.util.Arrays;
import java.util.List;

import edu.monash.fit2099.engine.Display;
import edu.monash.fit2099.engine.FancyGroundFactory;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.World;
import edu.monash.fit2099.engine.*;


public class Application {

	public static void main(String[] args) {
		World1 world = new World1(new Display());





		FancyGroundFactory groundFactory = new FancyGroundFactory(new Floor(), new Wall(), new LockedDoor(), new Water());
		GameMap gameMap;

		List<String> map = Arrays.asList(
				".......................",
				"....#####....######....",
				"....#...#....#....#....",
				"....#...+....#....#....",
				"....#####....##+###....",
				"........#..............",
				".......#.#.............",
				".......................",
				".......................",
				".................~~~~~~",
				".......................");
		gameMap = new GameMap(groundFactory, map);
		world.addMap(gameMap);



		List<String> moonBaseMap = Arrays.asList(
				"..............",
				"..#...........",
				".#.#..........",
				"..............",
				"..............",
				"..............",
				"..............",
				"..............",
				"..............",
				"..............",
				"..............",
				"..............",
				"..............",
				"..............");

		GameMap moonBase = new GameMap(groundFactory,moonBaseMap);
		world.addMap(moonBase);
		world.setMapToQuit(gameMap);


		Location earthRocketLocation = new Location(gameMap,8,6);
		Location moonRocketLocation = new Location(moonBase,0,3);



//		add player to map
		Player1 player = new Player1("Player1", '@', 1, 100);
		gameMap.addItem(new RocketPlans("RocketPlans"),5,3);
		player.setMaps(gameMap,moonBase,earthRocketLocation,moonRocketLocation);
		world.addPlayer(player, gameMap, 2, 2);


		
//		add rocket that will transport player from moon to earth.
		Rocket rocketMoon = new Rocket(earthRocketLocation,gameMap,player,"To Earth");
		//moonRocketLocation.setGround(rocketMoon);
		gameMap.add(rocketMoon,moonBase.at(0,3));

//		add rocket that will transport player from earth to moon		
		//Rocket rocketEarth = new Rocket(moonRocketLocation,moonBase,player,"To moon base");
		//earthRocketLocation.setGround(new Floor());
		//gameMap.add(rocketEarth,gameMap.at(8,6));
		//earthRocketLocation.setGround(rocketEarth);
		
		
//		Location earthRocketLocation = new Location(gameMap,8,6);
		RocketPad rocketPad = new RocketPad(player,moonRocketLocation);
		gameMap.add(rocketPad, gameMap.at(8, 6));

//		add grunts to map
		Grunt grunt = new Grunt("Mongo", player);
		grunt.addItemToInventory(new Key("Key",'k'));
		gameMap.addActor(grunt, 0, 0);
		Grunt grunt2 = new Grunt("Norbert", player);
		grunt2.addItemToInventory(new Key("Key",'k'));
		moonBase.addActor(grunt2,  6, 6);

//		add DrMaybe to map
		DrMaybe maybe = new DrMaybe(player);
		gameMap.addActor(maybe,15,2);

//		adding goon to map
		Goons goon1 = new Goons("Goon2",player);
		Goons goon2 = new Goons("Goon2",player);
		moonBase.addActor(goon1,5,5);
		gameMap.addActor(goon2,5,7);
		goon1.addItemToInventory(new Key("Key",'k'));
		goon2.addItemToInventory(new Key("Key",'k'));
		
//		adding ninja to map
		Ninja ninja = new Ninja("kage",player);
		ninja.addItemToInventory(new Key("Key",'k'));
		gameMap.addActor(ninja,6,6);

//		add Q to map
		Q q = new Q(player);
		gameMap.addActor(q,2,9);

		//Location earthRocketLocation = new Location(gameMap,0,2);
		//Rocket rocketEarth = new Rocket(new Location(moonBase,0,2),moonBase,player,"To moon base");


//		add YugoMaxx to map
		YugoMaxx ym = new YugoMaxx();
		moonBase.addActor(ym,11,4);

//		add water gun to map
		WaterGun wg = new WaterGun();
		moonBase.addItem(wg,0,8);
		
//		add oxygen dispenser to map
		Location odLocation = new Location(gameMap, 13,9);
		OxygenDispenser oxyDis = new OxygenDispenser(player, odLocation);
		gameMap.addItem(oxyDis, odLocation.x(), odLocation.y());


//		add spacesuit to map
		Spacesuit ss = new Spacesuit();
		gameMap.addItem(ss,0,9);
		
		world.run();
	}
}
