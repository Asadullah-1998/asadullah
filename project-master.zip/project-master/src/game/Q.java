package game;
import edu.monash.fit2099.engine.*;

/**
 * Class representing Q.
 * rocketPlans is the rocket plan that is required for building the rocket.
 *
 */
public class Q extends Actor {

    private RocketPlans rocketPlans;
    private Player1 player;


    public Q(Player1 player1){
        super("Q", 'Q', 5, 300);
        rocketPlans = new RocketPlans("RocketBody");
        player = player1;
    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Actor#getAllowableActions(edu.monash.fit2099.engine.Actor, java.lang.String, edu.monash.fit2099.engine.GameMap)
     */
    @Override
    public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {

        if (otherActor.equals(player)) {
            //return new Actions(new QAction(otherActor,this));
            Actions newActions = new Actions();

            for (Item item1: otherActor.getInventory()) {
                if (item1.toString().equals("RocketPlans")) {
                    newActions.add(new Talk(otherActor, this, "Hand them over. I dont have all day"));
                    newActions.add(new GivePlans(this,item1,player));
                    return newActions;
                }
            }
            return new Actions(new Talk(otherActor, this, "I can give you something that will help, but I’m going to need the plans"));
        } else{
            return new Actions(new AttackAction(otherActor, this));
        }
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Actor#playTurn(edu.monash.fit2099.engine.Actions, edu.monash.fit2099.engine.GameMap, edu.monash.fit2099.engine.Display)
     */
    @Override
    public Action playTurn(Actions actions, GameMap map, Display display) {
        /*for (Action action1: actions) {
            if (!(action1.getClass().equals(MoveActorAction)) || action1 instanceof SkipTurnAction){
                actions.remove(action1);
            }
        }*/
        Actions newAction = new Actions();
//        newAction.add(new MoveActorAction());
        newAction.add(new SkipTurnAction());

        for (Action action1:actions){
            if(action1 instanceof MoveActorAction){
                newAction.add(action1);
            }
        }

        return super.playTurn(newAction,map,display);

        //return super.playTurn(actions, map, display);
    }


    /*@Override
    public void addItemToInventory(Item item) {

        item.getAllowableActions().clear();
        item.getAllowableActions().add(new DropItemAction(item));

        super.addItemToInventory(item);
    }*/


}
