package game;

import edu.monash.fit2099.engine.Actions;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Location;

/**
 * Class for Oxygen Dispenser
 *
 */
public class OxygenDispenser extends Item {
	private boolean button;
	private Player1 player;
	private Location location;

	/**
	 * Constructor.
	 * 
	 * @param player1   player that the user controls
	 * @param location1 present location of the oxygen dispenser
	 */
	public OxygenDispenser(Player1 player1, Location location1) {
		// TODO Auto-generated constructor stub
		super("Oxygen Dispenser", 'O');
		player = player1;
		location = location1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.monash.fit2099.engine.Item#getAllowableActions()
	 */
	@Override
	public Actions getAllowableActions() {
		return new Actions(new GetOxygen(player, location));
	}
}
