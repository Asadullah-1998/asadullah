package game;

import java.util.ArrayList;
import java.util.List;
import edu.monash.fit2099.engine.*;

/**
 * Class representing Ninja
 *
 */
public class Ninja extends Actor {

	// Grunts have 50 hitpoints and are always represented with a g
	/**Constructor.
	 * @param name name to call ninja
	 * @param player player the user controls
	 */

	public Ninja(String name, Player1 player) {
		super(name, 'N', 5, 10);
		addBehaviour(new NinjaAttack(this, player));
	}

	@Override
	protected IntrinsicWeapon getIntrinsicWeapon() {
		return new IntrinsicWeapon(0, "stuns");
	}

	private List<ActionFactory> actionFactories = new ArrayList<ActionFactory>();

	private void addBehaviour(ActionFactory behaviour) {
		actionFactories.add(behaviour);
	}

	public Action playTurn(Actions actions, GameMap map, Display display) {
		/*
		 * if (isConscious()){ removeItemFromInventory(getItemFromName("RocketEngine"));
		 * }
		 */

		for (ActionFactory factory : actionFactories) {
			Action action = factory.getAction(this, map);
			if(action != null)
				return action;
		}

		Actions newActions = new Actions();
		newActions.add(new SkipTurnAction());

		return super.playTurn(newActions, map, display);
	}

	/**
	 * Moves the position of Ninja away from player by one unit
	 * @param actor Ninja
	 * @param subject player that the user control
	 * @param map	game map
	 */
	public void moveActorToPosition(Actor actor, Actor subject, GameMap map) {
		Location here = map.locationOf(actor);
		Location there = map.locationOf(subject);
		Location positionToMove = new Location(map, here.x(), here.y());


		if (here.x() == there.x()) {
			if (here.x() - there.x() < 0) {
				positionToMove = new Location(map, here.x() - 1, here.y());
			} else {
				positionToMove = new Location(map, here.x() + 1, here.y());
			}
		}

		if (here.y() == there.y()) {
			if (here.y() - there.y() < 0) {
				positionToMove = new Location(map, here.x(), here.y() - 1);
			} else {
				positionToMove = new Location(map, here.x(), here.y() + 1);
			}
		}

		if (positionToMove.getGround() != null){
			if (positionToMove.canActorEnter(this)) {
				map.moveActor(actor, positionToMove);
			}
		}
	}


}
