package game;
import edu.monash.fit2099.engine.*;




/**
 * Class defining water. Water is represented as ~ in map
 *
 */
public class Water extends Ground {

    public Water(){
        super('~');
    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Ground#allowableActions(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.Location, java.lang.String)
     */
    @Override
    public Actions allowableActions(Actor actor, Location location, String direction) {
        return new Actions(new DrawWaterAction());
        //return super.allowableActions(actor, location, direction);
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Ground#canActorEnter(edu.monash.fit2099.engine.Actor)
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
    }
}
