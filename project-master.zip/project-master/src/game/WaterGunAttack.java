package game;
import edu.monash.fit2099.engine.*;

import java.util.Random;


/**
 * Class that allows player to use water gun to attack
 *
 */
public class WaterGunAttack extends Action {

    private Random rand = new Random();
    private Actor target;
    private WaterGun waterGun;

    /**
     * Constructor
     * @param target1
     */
    public WaterGunAttack(Actor target1){
        super();
        target = target1;
    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#execute(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.GameMap)
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (hasWaterGun(actor)) {
            if (waterGun.getFull()) {
                waterGun.setFull(false);
                if (rand.nextDouble() <= 0.70) {
                    target.removeSkill(Keyskill.EXOSKELETON);
                    return "Exoskeleton is destroyed, Yugo can be hurt";
                } else {
                    return "Water missed";
                }
            } else {
                return "Water Gun not full";
            }
        } else {
            return "You cannot hurt Exoskeleton without a water gun";
        }

    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#menuDescription(edu.monash.fit2099.engine.Actor)
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor +" attacks the Exoskeleton";
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#hotKey()
     */
    @Override
    public String hotKey() {
        return "";
    }

    /**
     * method to check if player has water gun in his inventory
     * @param actor
     * @return
     */
    public boolean hasWaterGun(Actor actor){
        for (Item item1 : actor.getInventory()){
            if (item1.toString().equals("Water Gun")){
                waterGun = (((WaterGun) item1));
                return true;
            }
        }
        return false;
    }
}
