package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;

/**
 * Class defining GetOxgen action
 *
 */
public class GetOxygen extends Action {
	private Player1 player;
	private Location location;

	/**
	 * Constructor.
	 * 
	 * @param player1   player that the user controls
	 * @param location1 the location that the new oxygen tank will be generated
	 */
	public GetOxygen(Player1 player1, Location location1) {
		player = player1;
		location = location1;
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * edu.monash.fit2099.engine.Action#execute(edu.monash.fit2099.engine.Actor,
	 * edu.monash.fit2099.engine.GameMap)
	 */
	@Override
	public String execute(Actor actor, GameMap map) {

		if (actor.equals(player)) {
			(((Player1) actor)).setPressed(true);
			OxygenTank oxygenTank = ((OxygenTank) ((Player1) actor).getItemFromString("OxygenTank"));
			if (oxygenTank == null) {
				OxygenTank ot = new OxygenTank(10);
				map.addItem(ot, location.x(), location.y());
			} else {
				oxygenTank.addOxygenPoints(10);
			}
			// map.addItem(ot,location.x(),location.y());
		}

		return menuDescription(actor);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * edu.monash.fit2099.engine.Action#menuDescription(edu.monash.fit2099.engine.
	 * Actor)
	 */
	@Override
	public String menuDescription(Actor actor) {
		return actor + " takes oxygen from dispenser";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.monash.fit2099.engine.Action#hotKey()
	 */
	@Override
	public String hotKey() {
		return "";
	}
}
