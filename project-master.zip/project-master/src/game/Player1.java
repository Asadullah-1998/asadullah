package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actions;
import edu.monash.fit2099.engine.Display;
import edu.monash.fit2099.engine.DropItemAction;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.MoveActorAction;
import edu.monash.fit2099.engine.Player;
import edu.monash.fit2099.engine.SkipTurnAction;

/**
 * Class representing the Player.
 */
public class Player1 extends Player {

	private boolean isStunned;
	private static int stunTurn;

	private boolean isPressed;
	private int pressTurn;
	private GameMap moonMap;
	private GameMap mainMap;
	private Location earthRocketLocation;

	private Location moonRocketLocation;

	/**
	 * Constructor.
	 *
	 * @param name        Name to call the player in the UI
	 * @param displayChar Character to represent the player in the UI
	 * @param priority    How early in the turn the player can act
	 * @param hitPoints   Player's starting number of hitpoints
	 */
	public Player1(String name, char displayChar, int priority, int hitPoints) {
		super(name, displayChar, priority, hitPoints);
		isStunned = false;
		stunTurn = 2;

		isPressed = false;
		pressTurn = 2;

	}

	/**
	 * 
	 * @param mainMap1             earth map
	 * @param moonMap1             moon map
	 * @param earthRocketLocation1 location of the rocket that is on earth
	 * @param moonRocketLocation1  location of the rocket that is on moon
	 */
	public void setMaps(GameMap mainMap1, GameMap moonMap1, Location earthRocketLocation1,
			Location moonRocketLocation1) {

		moonMap = moonMap1;
		mainMap = mainMap1;

		earthRocketLocation = earthRocketLocation1;
		moonRocketLocation = moonRocketLocation1;

	}

	/**
	 * setters and getters
	 * 
	 * @return
	 */
	public boolean getStunned() {
		return isStunned;
	}

	/**
	 * setters and getters
	 * 
	 * @param isStunned1
	 */
	public void setStunned(boolean isStunned1) {
		isStunned = isStunned1;
	}

	/**
	 * setters and getters
	 * 
	 * @return
	 */
	public boolean getPressed() {
		return isPressed;
	}

	/**
	 * setters and getters
	 * 
	 * @param isPressed1
	 */
	public void setPressed(boolean isPressed1) {
		isPressed = isPressed1;
	}

	public Item getItemFromString(String string1) {

		for (Item item1 : this.getInventory()) {
			if (item1.toString().equals(string1)) {
				return item1;
			}
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * edu.monash.fit2099.engine.Player#playTurn(edu.monash.fit2099.engine.Actions,
	 * edu.monash.fit2099.engine.GameMap, edu.monash.fit2099.engine.Display)
	 */


	/**
	 * Play a turn. Doing this means displaying a menu to the user and getting their
	 * selected option.
	 *
	 * Ignores more than 26 options. We could do better. We could also roll out a
	 * dedicated menu class instead of having it here. Player is 90% menu.
	 *
	 * @param actions the actions to display
	 * @param map     the map to display
	 * @param display the object that performs the console I/O
	 * @return the Action that the user selects
	 */
	public Action playTurn(Actions actions, GameMap map, Display display) {
		if (stunTurn == 0 && getStunned()) {
			stunTurn = 2;
			setStunned(false);
		}

		if (getPressed() && pressTurn == 0) {
			pressTurn = 2;
			setPressed(false);
		}

		if (getStunned()) {
			display.println("Stunnnnnned");
		}

		if (getStunned() && stunTurn > 0) {
			stunTurn -= 1;
			return new SkipTurnAction();
		}

		if (getPressed() && pressTurn > 0) {
			pressTurn -= 1;
			return new SkipTurnAction();
		}

		if (map.equals(moonMap)) {
			if (getItemFromString("Spacesuit") != null) {
				OxygenTank oxygenTank = ((OxygenTank) getItemFromString("OxygenTank"));
				if (oxygenTank != null) {
					display.println("Number of Oxygen points in Oxygen tank: " + oxygenTank.getOxygenPoints());
					if (oxygenTank.getOxygenPoints() > 0) {
						oxygenTank.reduceOxygenPoints(1);
					} else {
						return new MoveActorAction(mainMap.at(earthRocketLocation.x(), earthRocketLocation.y()),
								"To Earth");
					}

				} else {
					return new MoveActorAction(mainMap.at(earthRocketLocation.x(), earthRocketLocation.y()),
							"To Earth");
				}
			} else {
				return new MoveActorAction(mainMap.at(earthRocketLocation.x(), earthRocketLocation.y()), "To Earth");
			}
		}

		actions.add(new QuitGameAction());
		return showMenu(actions, display);
	}

	/**
	 * item can be dropped
	 * 
	 * @param item
	 */
	public void giveItem(Item item) {
		item.getAllowableActions().clear();
		item.getAllowableActions().add(new DropItemAction(item));

		super.addItemToInventory(item);
	}

	/**
	 * Play a turn. Doing this means displaying a menu to the user and getting their
	 * selected option.
	 *
	 * Ignores more than 26 options. We could do better. We could also roll out a
	 * dedicated menu class instead of having it here. Player is 90% menu.
	 *
	 * @param actions the actions to display
	 * @param map     the map to display
	 * @param display the object that performs the console I/O
	 * @return the Action that the user selects
	 */

}
