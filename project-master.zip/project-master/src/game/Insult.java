package game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import edu.monash.fit2099.engine.*;

/**
 * Class representing insult action
 *
 */
public class Insult extends Action implements ActionFactory {

    private Actor target;
    public List<String> list = new ArrayList<String>();
    private Random rand = new Random();

    private Display display;

    /**
     * List of insults that Goons uses
     * @param subject	Goon
     */
    public Insult(Actor subject) {
        this.target = subject;
        addCurse("You Noob!");
        addCurse("qwer!@#!");
        addCurse("erty!");
        addCurse("asdf");
        display = new Display();

    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#execute(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.GameMap)
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        display.println("You are a noob");
        return menuDescription(actor);
//			actor.playTurn(SkipTurnAction, map, display);
    }


    /* (non-Javadoc)
     * @see game.ActionFactory#getAction(edu.monash.fit2099.engine.Actor, edu.monash.fit2099.engine.GameMap)
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        if (rand.nextDouble() <= 0.10) {
            return this;
        }
        return null;
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#menuDescription(edu.monash.fit2099.engine.Actor)
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor+" insults " + target;
    }

    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Action#hotKey()
     */
    @Override
    public String hotKey() {
        return "";
    }

    /**
     * method to add insult
     * @param curse
     */
    public void addCurse(String curse) {
        list.add(curse);
    }

    /**
     * method to generate random insults
     * @param list
     * @return
     */
    public String getRandomList(List<String> list) {

        int index = rand.nextInt(list.size());
        System.out.println("\nIndex :" + index);
        return list.get(index);

    }
}
