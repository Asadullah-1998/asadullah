package game;
import edu.monash.fit2099.engine.*;



/**
 * Class for rocket
 *
 */
public class Rocket extends Ground {

    private Location goToLocation;
    private GameMap goToMap;
    private Actor player;
    private String goToName;


    /**
     * method to move actor from one map to another
     * @param goto1
     * @param map1
     * @param player1
     * @param name1
     */
    public Rocket(Location goto1, GameMap map1, Actor player1, String name1){
        super('^');
        goToLocation = goto1;
        goToMap = map1;
        player = player1;
        goToName = name1;
    }


    /* (non-Javadoc)
     * @see edu.monash.fit2099.engine.Item#getAllowableActions()
     */
//    public Actions getAllowableActions() {
//        return new Actions(new MoveActorAction(goToMap.at(goToLocation.x(),goToLocation.y()),goToName));
//    }


    @Override
    public Actions allowableActions(Actor actor, Location location, String direction) {
        if (actor.equals(player)) {
            return new Actions(new MoveActorAction(goToMap.at(goToLocation.x(), goToLocation.y()), goToName));
        }
        return new Actions();
    }

    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
        //return super.canActorEnter(actor);
    }
}
