package game;

public enum Keyskill {
	OPENDOOR,
	EXOSKELETON;
}
