package game;

import edu.monash.fit2099.engine.Item;

/**
 * Class for Rocket Plans
 *
 */
public class RocketPlans extends Item {

    public RocketPlans(String name1){
        super(name1,'r');

    }




}
