package edu.monash.fit2099.demo;

public enum DemoSkills {
	SPACETRAVELLER;
}
